package com.agung.pbmacro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 48, 28, 28);
        root.setBackgroundColor(Color.rgb(18, 20, 28));

        TextView title = new TextView(this);
        title.setText("PB MACRO CONTROLLER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Point Blank Mobile • TEST MODE");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 12;
        root.addView(subtitle, sp);

        EditText delay = new EditText(this);
        delay.setSingleLine(true);
        delay.setInputType(2);
        delay.setText("300");
        delay.setHint("Delay (ms)");
        delay.setTextColor(Color.WHITE);
        delay.setHintTextColor(Color.GRAY);
        delay.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.GRAY));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = 36;
        root.addView(delay, dp);

        Button start = new Button(this);
        start.setText("START TEST");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 24;
        root.addView(start, bp);

        Button stop = new Button(this);
        stop.setText("STOP");
        root.addView(stop, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Status: STOPPED");
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = 28;
        root.addView(status, stp);

        TextView note = new TextView(this);
        note.setText("Versi awal hanya menguji tombol di dalam aplikasi. Tidak mengirim sentuhan ke game atau melewati anti-cheat.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 28;
        root.addView(note, np);

        start.setOnClickListener(v -> status.setText("Status: TEST MODE • Delay " + delay.getText() + " ms"));
        stop.setOnClickListener(v -> status.setText("Status: STOPPED"));

        setContentView(root);
    }
}
